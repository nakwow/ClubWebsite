// =====================================================================
// app.js
// ---------------------------------------------------------------------
// This file runs in the BROWSER. It does NOT store any real data
// itself - every time it needs clubs/events/announcements, it asks
// the server for them using fetch(), and the server gets the real
// answer from the SQLite database (see db.js on the server).
//
// Think of it in three parts:
//   1. "State" - a few JavaScript variables that hold a COPY of
//      whatever the server last told us, so we can draw the page
//      without re-asking the server every second.
//   2. "Render" functions - turn that state into HTML strings.
//   3. "Event handlers" - respond to clicks/typing, call the API,
//      then re-render.
// =====================================================================

// ---------------------------------------------------------------------
// STATE (a local copy of server data, refreshed after every change)
// ---------------------------------------------------------------------
var currentUser = null; // filled in once we confirm the user is logged in
var clubs = [];
var events = [];
var announcements = [];

// ---------------------------------------------------------------------
// STARTUP
// ---------------------------------------------------------------------
// The very first thing we do is ask the server "am I logged in?"
// If not, we bounce the visitor to the login page.
fetch('/api/me')
  .then(function (res) {
    if (!res.ok) throw new Error('not logged in');
    return res.json();
  })
  .then(function (user) {
    currentUser = user;
    showProfileInSidebar(user);
    return loadAllData(); // fetch clubs/events/announcements, then draw dashboard
  })
  .catch(function () {
    window.location.href = '/login.html';
  });

// Fetches clubs, events, and announcements from the server at the same
// time, waits for all three, then shows the dashboard.
function loadAllData() {
  return Promise.all([
    fetch('/api/clubs').then(function (r) { return r.json(); }),
    fetch('/api/events').then(function (r) { return r.json(); }),
    fetch('/api/announcements').then(function (r) { return r.json(); })
  ]).then(function (results) {
    clubs = results[0];
    events = results[1];
    announcements = results[2];
    populateClubDropdown();
    navigateTo('dashboard');
  });
}

function showProfileInSidebar(user) {
  document.getElementById('profileName').textContent = user.fullName;
  document.getElementById('profileRole').textContent = user.role;
  var initials = user.fullName.split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
  document.getElementById('userAvatar').textContent = initials;
}

// ---------------------------------------------------------------------
// HELPER FUNCTIONS FOR BUILDING HTML
// ---------------------------------------------------------------------

var MONTH_NAMES = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

function formatDateBadge(dateStr) {
  // dateStr looks like '2026-10-06'
  var parts = dateStr.split('-');
  var month = MONTH_NAMES[parseInt(parts[1], 10) - 1];
  return { day: parts[2], month: month };
}

function buildEventList(eventArray) {
  if (!eventArray || eventArray.length === 0) {
    return '<p class="empty-state">No events found.</p>';
  }
  var html = '<ul class="event-list">';
  for (var i = 0; i < eventArray.length; i++) {
    var ev = eventArray[i];
    var badge = formatDateBadge(ev.date);
    html += '<li class="event-item">' +
      '<div class="event-date-box">' +
        '<span class="date-num">' + badge.day + '</span>' +
        '<span class="date-month">' + badge.month + '</span>' +
      '</div>' +
      '<div class="event-details">' +
        '<span class="event-title" style="font-weight:600;">' + ev.title + '</span>' +
        '<span class="event-meta">' + ev.clubName + ' &bull; ' + ev.location + '</span>' +
      '</div>' +
      (currentUser ? '<button class="icon-btn" onclick="deleteEvent(' + ev.id + ')" title="Delete event">&times;</button>' : '') +
    '</li>';
  }
  html += '</ul>';
  return html;
}

// Builds a calendar grid for the CURRENT real month, and marks any day
// that has an event registered against it.
function buildCalendarGrid() {
  var today = new Date();
  var year = today.getFullYear();
  var month = today.getMonth(); // 0-11

  var firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 = Sunday
  var daysInMonth = new Date(year, month + 1, 0).getDate();

  // Work out which day-numbers have at least one event.
  var eventDaysInThisMonth = {};
  for (var i = 0; i < events.length; i++) {
    var parts = events[i].date.split('-');
    var evYear = parseInt(parts[0], 10);
    var evMonth = parseInt(parts[1], 10) - 1;
    var evDay = parseInt(parts[2], 10);
    if (evYear === year && evMonth === month) {
      eventDaysInThisMonth[evDay] = true;
    }
  }

  var html = '<div class="calendar-grid">' +
    '<div class="day-label">Sun</div><div class="day-label">Mon</div><div class="day-label">Tue</div>' +
    '<div class="day-label">Wed</div><div class="day-label">Thu</div><div class="day-label">Fri</div><div class="day-label">Sat</div>';

  // Blank cells before day 1
  for (var b = 0; b < firstDayOfMonth; b++) {
    html += '<div class="day cell-disabled"></div>';
  }

  for (var d = 1; d <= daysInMonth; d++) {
    var isToday = (d === today.getDate());
    html += '<div class="day ' + (isToday ? 'today' : '') + '">' +
      '<span class="day-number">' + d + '</span>' +
      (eventDaysInThisMonth[d] ? '<span class="event-tag">Event</span>' : '') +
    '</div>';
  }

  html += '</div>';
  return { html: html, monthName: today.toLocaleString('default', { month: 'long' }), year: year };
}

function populateClubDropdown() {
  var select = document.getElementById('eventClubInput');
  select.innerHTML = '';
  for (var i = 0; i < clubs.length; i++) {
    var option = document.createElement('option');
    option.value = clubs[i].id;
    option.textContent = clubs[i].name;
    select.appendChild(option);
  }
}

// ---------------------------------------------------------------------
// PAGE RENDERERS - each one returns an HTML string for one "page"
// ---------------------------------------------------------------------

function renderDashboard() {
  var calendar = buildCalendarGrid();
  return '<div class="metrics-row">' +
    '<div class="card metric-card"><span class="metric-title">Registered Clubs</span><span class="metric-value">' + clubs.length + '</span></div>' +
    '<div class="card metric-card"><span class="metric-title">Upcoming Events</span><span class="metric-value">' + events.length + '</span></div>' +
    '<div class="card metric-card"><span class="metric-title">Announcements</span><span class="metric-value">' + announcements.length + '</span></div>' +
  '</div>' +
  '<div class="content-split">' +
    '<div class="card"><h3>' + calendar.monthName + ' ' + calendar.year + '</h3><br>' + calendar.html + '</div>' +
    '<div class="card"><h3>Upcoming Activities</h3><br><div id="dashboardEvents">' + buildEventList(events) + '</div></div>' +
  '</div>';
}

function renderCalendar() {
  var calendar = buildCalendarGrid();
  return '<div class="card"><h2>' + calendar.monthName + ' ' + calendar.year + '</h2><br>' + calendar.html + '</div>';
}

function renderSocieties() {
  var html = '<div class="section-header" style="margin-bottom:1rem;">' +
    '<h2>Clubs &amp; Societies</h2>' +
    (currentUser ? '<button class="btn btn-primary" id="openClubModalBtn">+ Register Club</button>' : '') +
  '</div>';

  html += '<div class="grid-3">';
  for (var i = 0; i < clubs.length; i++) {
    var c = clubs[i];
    html += '<div class="card society-card">' +
      '<div class="club-header-row">' +
        '<span class="badge">' + c.category + '</span>' +
        (currentUser ? '<button class="icon-btn" onclick="deleteClub(' + c.id + ')" title="Delete club">&times;</button>' : '') +
      '</div>' +
      '<h3>' + c.name + '</h3>' +
      '<p style="color:var(--text-muted); font-size:0.85rem;">' + (c.description || '') + '</p>' +
      '<p style="color:var(--text-muted); font-size:0.85rem;">Members: ' + c.members + '</p>' +
    '</div>';
  }
  html += '</div>';
  return html;
}

function renderAnnouncements() {
  var html = '';

  if (currentUser) {
    html += '<div class="card" style="margin-bottom:1.5rem;">' +
      '<h3>Post an Announcement</h3><br>' +
      '<form id="announcementForm">' +
        '<div class="form-group"><label>Title</label><input type="text" id="annTitleInput" required></div>' +
        '<div class="form-group"><label>Posted On Behalf Of</label><input type="text" id="annClubInput" placeholder="Students\' Union" value="Students\' Union"></div>' +
        '<div class="form-group"><label>Message</label><textarea id="annBodyInput" rows="3" required></textarea></div>' +
        '<button type="submit" class="btn btn-primary">Post Announcement</button>' +
      '</form>' +
    '</div>';
  }

  html += '<div class="stack-layout">';
  if (announcements.length === 0) {
    html += '<p class="empty-state">No announcements yet.</p>';
  }
  for (var i = 0; i < announcements.length; i++) {
    var a = announcements[i];
    html += '<div class="card announcement-card">' +
      '<h3>' + a.title + '</h3>' +
      '<span class="badge" style="margin-top:0.5rem;">' + a.club + '</span>' +
      '<p style="margin-top:0.75rem;">' + a.body + '</p>' +
      '<div class="announcement-meta">Posted on ' + a.date + '</div>' +
    '</div>';
  }
  html += '</div>';
  return html;
}

function renderSettings() {
  return '<div class="card" style="max-width:500px;">' +
    '<h2>User Settings</h2><br>' +
    '<div class="form-group"><label>Full Name</label><input type="text" id="setName" value="' + currentUser.fullName + '"></div>' +
    '<div class="form-group"><label>College / University</label><input type="text" id="setCollege" value="' + currentUser.college + '"></div>' +
    '<br><button class="btn btn-primary" id="saveSettingsBtn">Save Settings</button>' +
  '</div>';
}

// ---------------------------------------------------------------------
// NAVIGATION
// ---------------------------------------------------------------------
function navigateTo(page) {
  var container = document.getElementById('pageContainer');
  if (!container) return;

  var navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(function (item) {
    item.classList.toggle('active', item.getAttribute('data-page') === page);
  });

  if (page === 'dashboard') container.innerHTML = renderDashboard();
  else if (page === 'calendar') container.innerHTML = renderCalendar();
  else if (page === 'societies') container.innerHTML = renderSocieties();
  else if (page === 'announcements') container.innerHTML = renderAnnouncements();
  else if (page === 'settings') container.innerHTML = renderSettings();

  attachPageHandlers(page);
}

// Some pages create their own buttons/forms dynamically (since they
// only exist once the HTML string above has been inserted), so we
// wire up their click/submit listeners here, every time we navigate.
function attachPageHandlers(page) {
  if (page === 'societies' && currentUser) {
    var openClubModalBtn = document.getElementById('openClubModalBtn');
    if (openClubModalBtn) {
      openClubModalBtn.addEventListener('click', function () {
        document.getElementById('clubModal').style.display = 'flex';
      });
    }
  }

  if (page === 'announcements' && currentUser) {
    var annForm = document.getElementById('announcementForm');
    if (annForm) {
      annForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var title = document.getElementById('annTitleInput').value;
        var club = document.getElementById('annClubInput').value;
        var body = document.getElementById('annBodyInput').value;

        fetch('/api/announcements', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: title, club: club, body: body })
        })
          .then(function (r) { return r.json(); })
          .then(function (newAnnouncement) {
            announcements.unshift(newAnnouncement);
            navigateTo('announcements');
          });
      });
    }
  }

  if (page === 'settings') {
    var saveBtn = document.getElementById('saveSettingsBtn');
    if (saveBtn) saveBtn.addEventListener('click', saveSettings);
  }
}

// ---------------------------------------------------------------------
// ACTIONS THAT TALK TO THE SERVER
// ---------------------------------------------------------------------

function saveSettings() {
  var fullName = document.getElementById('setName').value;
  var college = document.getElementById('setCollege').value;

  fetch('/api/me', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fullName: fullName, college: college })
  })
    .then(function () {
      currentUser.fullName = fullName;
      currentUser.college = college;
      showProfileInSidebar(currentUser);
      alert('Settings saved!');
    });
}

window.deleteClub = function (clubId) {
  if (!confirm('Delete this club? Its events will be removed too.')) return;
  fetch('/api/clubs/' + clubId, { method: 'DELETE' })
    .then(function () { return loadAllData(); })
    .then(function () { navigateTo('societies'); });
};

window.deleteEvent = function (eventId) {
  if (!confirm('Delete this event?')) return;
  fetch('/api/events/' + eventId, { method: 'DELETE' })
    .then(function () { return loadAllData(); });
};

// ---------------------------------------------------------------------
// SEARCH BAR (filters the dashboard's event list as you type)
// ---------------------------------------------------------------------
document.getElementById('globalSearch').addEventListener('input', function (e) {
  var query = e.target.value.toLowerCase();
  var filtered = events.filter(function (ev) {
    return ev.title.toLowerCase().indexOf(query) !== -1 || ev.clubName.toLowerCase().indexOf(query) !== -1;
  });
  var eventBox = document.getElementById('dashboardEvents');
  if (eventBox) eventBox.innerHTML = buildEventList(filtered);
});

// ---------------------------------------------------------------------
// EVENT REGISTRATION MODAL
// ---------------------------------------------------------------------
var eventModal = document.getElementById('eventModal');
document.getElementById('openModalBtn').addEventListener('click', function () {
  eventModal.style.display = 'flex';
});
document.getElementById('closeModal').addEventListener('click', function () {
  eventModal.style.display = 'none';
});

document.getElementById('eventForm').addEventListener('submit', function (e) {
  e.preventDefault();
  var title = document.getElementById('eventTitleInput').value;
  var clubId = document.getElementById('eventClubInput').value;
  var date = document.getElementById('eventDateInput').value;
  var location = document.getElementById('eventLocationInput').value;

  fetch('/api/events', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: title, clubId: clubId, date: date, location: location })
  })
    .then(function (r) { return r.json(); })
    .then(function () {
      eventModal.style.display = 'none';
      document.getElementById('eventForm').reset();
      return loadAllData();
    })
    .then(function () { navigateTo('dashboard'); });
});

// ---------------------------------------------------------------------
// CLUB REGISTRATION MODAL
// ---------------------------------------------------------------------
var clubModal = document.getElementById('clubModal');
document.getElementById('closeClubModal').addEventListener('click', function () {
  clubModal.style.display = 'none';
});

document.getElementById('clubForm').addEventListener('submit', function (e) {
  e.preventDefault();
  var name = document.getElementById('clubNameInput').value;
  var category = document.getElementById('clubCategoryInput').value;
  var description = document.getElementById('clubDescriptionInput').value;

  fetch('/api/clubs', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name, category: category, description: description })
  })
    .then(function (r) { return r.json(); })
    .then(function () {
      clubModal.style.display = 'none';
      document.getElementById('clubForm').reset();
      return loadAllData();
    })
    .then(function () { navigateTo('societies'); });
});

// ---------------------------------------------------------------------
// SIDEBAR NAVIGATION + LOGOUT
// ---------------------------------------------------------------------
document.getElementById('navMenu').addEventListener('click', function (e) {
  if (e.target.classList.contains('nav-item')) {
    var page = e.target.getAttribute('data-page');
    navigateTo(page);
  }
});

document.getElementById('logoutBtn').addEventListener('click', function () {
  fetch('/api/logout', { method: 'POST' }).then(function () {
    window.location.href = '/login.html';
  });
});
